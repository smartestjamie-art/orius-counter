int uvc_open(int vid, int pid);
int uvc_control(int request, int unit, int selector, int len, int *value);
