// Minimal UVC control access for a USB camera (focus etc.) via IOKit.
#include <IOKit/IOKitLib.h>
#include <IOKit/IOCFPlugIn.h>
#include <IOKit/usb/IOUSBLib.h>
#include <stdio.h>
#include "uvc.h"

static IOUSBInterfaceInterface **vc = NULL;
static int vcNumber = 0;

int uvc_open(int vid, int pid) {
    if (vc) { (*vc)->Release(vc); vc = NULL; } // reopening, e.g. after the camera was replugged
    CFMutableDictionaryRef match = IOServiceMatching(kIOUSBInterfaceClassName);
    io_iterator_t it;
    if (IOServiceGetMatchingServices(kIOMainPortDefault, match, &it) != KERN_SUCCESS) return -1;
    io_service_t s;
    while ((s = IOIteratorNext(it))) {
        IOCFPlugInInterface **plug = NULL; SInt32 score;
        if (IOCreatePlugInInterfaceForService(s, kIOUSBInterfaceUserClientTypeID, kIOCFPlugInInterfaceID, &plug, &score) == KERN_SUCCESS && plug) {
            IOUSBInterfaceInterface **intf = NULL;
            (*plug)->QueryInterface(plug, CFUUIDGetUUIDBytes(kIOUSBInterfaceInterfaceID), (LPVOID *)&intf);
            (*plug)->Release(plug);
            if (intf) {
                UInt16 v = 0, p = 0; UInt8 cls = 0, sub = 0, num = 0;
                (*intf)->GetDeviceVendor(intf, &v); (*intf)->GetDeviceProduct(intf, &p);
                (*intf)->GetInterfaceClass(intf, &cls); (*intf)->GetInterfaceSubClass(intf, &sub);
                (*intf)->GetInterfaceNumber(intf, &num);
                if (v == vid && p == pid && cls == 14 && sub == 1) { vc = intf; vcNumber = num; IOObjectRelease(s); break; }
                (*intf)->Release(intf);
            }
        }
        IOObjectRelease(s);
    }
    IOObjectRelease(it);
    return vc ? 0 : -2;
}

// request: 0x81 GET_CUR, 0x82 GET_MIN, 0x83 GET_MAX, 0x84 GET_RES, 0x01 SET_CUR
int uvc_control(int request, int unit, int selector, int len, int *value) {
    if (!vc) return -1;
    UInt8 buf[4] = {0};
    if (request == 0x01) for (int i = 0; i < len; i++) buf[i] = (*value >> (8 * i)) & 0xff;
    IOUSBDevRequest r;
    r.bmRequestType = request == 0x01 ? 0x21 : 0xA1;
    r.bRequest = request;
    r.wValue = selector << 8;
    r.wIndex = (unit << 8) | vcNumber;
    r.wLength = len;
    r.pData = buf;
    IOReturn e = (*vc)->ControlRequest(vc, 0, &r);
    if (e != kIOReturnSuccess) return e;
    if (request != 0x01) {
        int v = 0;
        for (int i = 0; i < len; i++) v |= buf[i] << (8 * i);
        if (len == 2) v = (int16_t)v;
        *value = v;
    }
    return 0;
}
