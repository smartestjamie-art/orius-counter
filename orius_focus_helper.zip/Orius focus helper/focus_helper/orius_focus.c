// Orius focus helper: lets the Orius Counter web page set the Arducam's focus, which browsers on
// macOS cannot. Serves http://127.0.0.1:8777/focus on this Mac only.
//   GET /focus             -> {"min":..,"max":..,"value":..,"auto":0|1}
//   GET /focus?value=N     -> manual focus at N (autofocus off)
//   GET /focus?auto=1|0    -> autofocus on/off
//   GET /camera            -> exposure (auto or manual, 0.1 ms units), gain, sharpness, contrast, gamma:
//                             {"<name>":{"min":..,"max":..,"value":..},...,"auto_exposure":0|1}
//   GET /camera?<name>=N   -> set one (exposure=N also turns auto exposure off); ?auto_exposure=1|0
// Usage: orius_focus [vendor_id product_id]   (default: Arducam 16MP, 3141 25453)
#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include "../uvc.h"

#define FOCUS_ABS 0x06
#define FOCUS_AUTO 0x08
#define AE_MODE 0x02        // camera terminal: 1 manual, 8 aperture priority (auto)
#define CT 1                // camera terminal unit
#define PU 2                // processing unit (Arducam 16MP)

// Image controls the page can set: unit, selector, length in bytes.
static const struct { const char *name; int unit, sel, len; } CONTROLS[] = {
    {"exposure", CT, 0x04, 4}, {"gain", PU, 0x04, 2}, {"sharpness", PU, 0x08, 2},
    {"contrast", PU, 0x03, 2}, {"gamma", PU, 0x09, 2},
};
#define NCONTROLS (int)(sizeof CONTROLS / sizeof CONTROLS[0])

static int get(int request, int selector, int len) { int v = 0; return uvc_control(request, 1, selector, len, &v) == 0 ? v : -1; }
static int getu(int request, int unit, int selector, int len, int *v) { return uvc_control(request, unit, selector, len, v); }

// {"exposure":{"min":1,"max":5000,"value":157},...,"auto_exposure":1}
static void camera_json(char *body, size_t size) {
    size_t n = snprintf(body, size, "{");
    for (int i = 0; i < NCONTROLS; i++) {
        int lo = 0, hi = 0, v = 0;
        if (getu(0x82, CONTROLS[i].unit, CONTROLS[i].sel, CONTROLS[i].len, &lo) ||
            getu(0x83, CONTROLS[i].unit, CONTROLS[i].sel, CONTROLS[i].len, &hi) ||
            getu(0x81, CONTROLS[i].unit, CONTROLS[i].sel, CONTROLS[i].len, &v)) continue;
        n += snprintf(body + n, size - n, "\"%s\":{\"min\":%d,\"max\":%d,\"value\":%d},", CONTROLS[i].name, lo, hi, v);
    }
    int ae = 0;
    getu(0x81, CT, AE_MODE, 1, &ae);
    snprintf(body + n, size - n, "\"auto_exposure\":%d}", ae == 1 ? 0 : 1);
}

static void reply(int fd, int status, const char *body) {
    char head[512];
    snprintf(head, sizeof head,
             "HTTP/1.1 %d %s\r\nContent-Type: application/json\r\nContent-Length: %zu\r\n"
             "Access-Control-Allow-Origin: *\r\nAccess-Control-Allow-Methods: GET, OPTIONS\r\n"
             "Access-Control-Allow-Headers: *\r\nAccess-Control-Allow-Private-Network: true\r\n"
             "Cache-Control: no-store\r\nConnection: close\r\n\r\n",
             status, status == 200 ? "OK" : status == 204 ? "No Content" : "Not Found", strlen(body));
    write(fd, head, strlen(head));
    write(fd, body, strlen(body));
}

int main(int argc, char **argv) {
    int vid = argc > 2 ? atoi(argv[1]) : 3141, pid = argc > 2 ? atoi(argv[2]) : 25453;
    if (uvc_open(vid, pid) != 0) { fprintf(stderr, "Camera %d:%d not found. Is the Arducam plugged in?\n", vid, pid); return 1; }
    int lo = get(0x82, FOCUS_ABS, 2), hi = get(0x83, FOCUS_ABS, 2);
    if (hi <= lo) { fprintf(stderr, "This camera has no manual focus control.\n"); return 1; }

    int srv = socket(AF_INET, SOCK_STREAM, 0), on = 1;
    setsockopt(srv, SOL_SOCKET, SO_REUSEADDR, &on, sizeof on);
    struct sockaddr_in a = {0};
    a.sin_family = AF_INET; a.sin_port = htons(8777); a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    if (bind(srv, (struct sockaddr *)&a, sizeof a) || listen(srv, 8)) { perror("Port 8777"); return 1; }
    printf("Orius focus helper running: focus %d-%d. Leave this window open while using the web page.\n", lo, hi);
    fflush(stdout);

    for (;;) {
        int fd = accept(srv, NULL, NULL);
        if (fd < 0) continue;
        char req[2048] = {0};
        read(fd, req, sizeof req - 1);
        char body[256];
        if (!strncmp(req, "OPTIONS ", 8)) reply(fd, 204, "");
        else if (!strncmp(req, "GET /focus", 10)) {
            // The camera's handle goes stale when it is replugged or the Mac sleeps: reconnect.
            if (get(0x81, FOCUS_AUTO, 1) < 0) uvc_open(vid, pid);
            char *q = strchr(req, '?'), *end = strchr(req + 4, ' ');
            if (q && end && q < end) {
                int v;
                if (sscanf(q, "?value=%d", &v) == 1) {
                    int off = 0; uvc_control(0x01, 1, FOCUS_AUTO, 1, &off);
                    v = v < lo ? lo : v > hi ? hi : v;
                    uvc_control(0x01, 1, FOCUS_ABS, 2, &v);
                } else if (sscanf(q, "?auto=%d", &v) == 1) {
                    v = v ? 1 : 0; uvc_control(0x01, 1, FOCUS_AUTO, 1, &v);
                }
            }
            snprintf(body, sizeof body, "{\"min\":%d,\"max\":%d,\"value\":%d,\"auto\":%d}",
                     lo, hi, get(0x81, FOCUS_ABS, 2), get(0x81, FOCUS_AUTO, 1));
            reply(fd, 200, body);
        } else if (!strncmp(req, "GET /camera", 11)) {
            if (get(0x81, FOCUS_AUTO, 1) < 0) uvc_open(vid, pid);
            char *q = strchr(req, '?'), *end = strchr(req + 4, ' ');
            if (q && end && q < end) {
                char name[32]; int v;
                if (sscanf(q + 1, "%31[a-z_]=%d", name, &v) == 2) {
                    if (!strcmp(name, "auto_exposure")) { int m = v ? 8 : 1; uvc_control(0x01, CT, AE_MODE, 1, &m); }
                    for (int i = 0; i < NCONTROLS; i++) if (!strcmp(name, CONTROLS[i].name)) {
                        int lo = 0, hi = 0;
                        getu(0x82, CONTROLS[i].unit, CONTROLS[i].sel, CONTROLS[i].len, &lo);
                        getu(0x83, CONTROLS[i].unit, CONTROLS[i].sel, CONTROLS[i].len, &hi);
                        if (CONTROLS[i].unit == CT) { int m = 1; uvc_control(0x01, CT, AE_MODE, 1, &m); } // manual exposure
                        v = v < lo ? lo : v > hi ? hi : v;
                        uvc_control(0x01, CONTROLS[i].unit, CONTROLS[i].sel, CONTROLS[i].len, &v);
                    }
                }
            }
            char cam[512];
            camera_json(cam, sizeof cam);
            reply(fd, 200, cam);
        } else reply(fd, 404, "{}");
        close(fd);
    }
}
