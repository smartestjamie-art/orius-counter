#!/bin/zsh
# Double-click to let the Orius Counter web page control the Arducam's focus. Keep the window open.
cd "$(dirname "$0")"
xattr -dr com.apple.quarantine .. 2>/dev/null  # a downloaded copy is otherwise blocked by macOS
if [ ! -x orius_focus ] || [ orius_focus.c -nt orius_focus ]; then
  clang -O2 -arch arm64 -arch x86_64 -o orius_focus orius_focus.c ../uvc.c -framework IOKit -framework CoreFoundation || exit 1
fi
./orius_focus
